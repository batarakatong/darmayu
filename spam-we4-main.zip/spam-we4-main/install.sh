apt update 
apt upgrade
pkg install jq
pkg install curl
pip install requests
pkg install pip2
Pkg install python
pkg install python2
pkg install python3
