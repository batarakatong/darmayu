# spam-we4
```
Tools ini dibuat untuk ngerjain
Kang Ripper atau boleh juga buat
nyepam Mantan Lu awokawokwkwk:v
```
![h20 studio] (https://github.com/HendarOfficial/spam-we4/blob/main/h20%20studio.jpg )
> Script ini sewaktu-waktu bisa jadi limit ataupun coid jadi jangan salahin author nya ya.
## How to it?
```python
$ cd spam-we4
$ bash install.sh
```
## Support Me On
<b>• [Instagram](https://www.instagram.com/hendar_scripter)</b>
<br>
<b>• [Youtube](https://www.youtube.com/c/HendarOfficial1 )</b>
</br>
